const products = [
  {
    "id": "drip-slit-30",
    "name": "Drip Tape (Slit Emitter, 30cm spacing)",
    "specs": "16mm \u00d7 0.2mm \u00d7 2000m roll",
    "price": "KES 9,500",
    "image": "/products/driptape-slit.jpg",
    "category": "Drip Irrigation",
    "description": "Economical slit tape for vegetables."
  },
  {
    "id": "drip-flat-30",
    "name": "Drip Tape (Flat Dripper, 30cm spacing)",
    "specs": "16mm \u00d7 0.3mm \u00d7 2000m roll",
    "price": "KES 12,000",
    "image": "/products/driptape-flat.jpg",
    "category": "Drip Irrigation",
    "description": "Durable flat dripper tape for longer life."
  },
  {
    "id": "layflat-1",
    "name": "Black Layflat Hose 1\" (PN10)",
    "specs": "100m roll",
    "price": "KES 6,800",
    "image": "/products/layflat-1.jpg",
    "category": "Pipes & Hoses",
    "description": "Light duty layflat for small farms."
  },
  {
    "id": "layflat-15",
    "name": "Black Layflat Hose 1.5\" (PN10)",
    "specs": "100m roll",
    "price": "KES 9,200",
    "image": "/products/layflat-15.jpg",
    "category": "Pipes & Hoses",
    "description": "Standard contractor size."
  },
  {
    "id": "filter-screen-1",
    "name": "Screen Filter 1\"",
    "specs": "Compact for small farms",
    "price": "KES 2,500",
    "image": "/products/screen-filter-1.jpg",
    "category": "Filters",
    "description": "Easy-to-clean mesh screen filter."
  },
  {
    "id": "filter-disc-15",
    "name": "Disc Filter 1.5\"",
    "specs": "Higher capacity disc filter",
    "price": "KES 4,500",
    "image": "/products/disc-filter-15.jpg",
    "category": "Filters",
    "description": "Disc filter for medium farms."
  },
  {
    "id": "dripper-xf1207",
    "name": "Adjustable Online Dripper (XF1207) pack 100",
    "specs": "Adjustable dripper pack",
    "price": "KES 1,200",
    "image": "/products/dripper-xf1207.jpg",
    "category": "Drip Irrigation",
    "description": "Adjustable flow dripper."
  },
  {
    "id": "grommet-pack",
    "name": "Grommet + Offtake Connector pack 100",
    "specs": "Grommet + offtake pack",
    "price": "KES 1,000",
    "image": "/products/grommet-pack.jpg",
    "category": "Fittings",
    "description": "Grommets and connectors for drip."
  },
  {
    "id": "butterfly-05",
    "name": "Butterfly Sprinkler \u00bd\" Male",
    "specs": "Radius 6\u20137 m",
    "price": "KES 350",
    "image": "/products/butterfly-05.jpg",
    "category": "Sprinklers",
    "description": "Easy-install butterfly sprinkler."
  },
  {
    "id": "footvalve-1",
    "name": "PVC Foot Valve 1\"",
    "specs": "Standard foot valve",
    "price": "KES 1,800",
    "image": "/products/footvalve-1.jpg",
    "category": "Valves",
    "description": "Protects pump from backflow."
  }
];
export default products;
