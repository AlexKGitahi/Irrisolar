import Head from 'next/head'
import Header from '../../components/Header'
import Footer from '../../components/Footer'
export default function Blog(){ return (<div><Head><title>Blog - Irrisolar</title></Head><Header/><main className='pt-20 max-w-3xl mx-auto p-4'><h1 className='text-2xl font-bold mb-4'>Learn More</h1><a href='/blog/drip-vs-sprinkler' className='block bg-white p-3 rounded shadow mb-3'>Drip vs Sprinkler</a><a href='/blog/choose-filter' className='block bg-white p-3 rounded shadow'>How to Choose a Filter</a></main><Footer/></div>) }
