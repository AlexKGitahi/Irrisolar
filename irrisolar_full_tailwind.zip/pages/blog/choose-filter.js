import Header from '../../components/Header'
import Footer from '../../components/Footer'
export default function Article(){ return (<div><Header/><main className='pt-20 max-w-3xl mx-auto p-4'><h1 className='text-2xl font-bold'>How to Choose a Filter</h1><p className='mt-2'>Short guide about screen vs disc filters...</p></main><Footer/></div>) }
