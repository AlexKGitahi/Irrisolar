import Header from '../../components/Header'
import Footer from '../../components/Footer'
export default function Article(){ return (<div><Header/><main className='pt-20 max-w-3xl mx-auto p-4'><h1 className='text-2xl font-bold'>Drip vs Sprinkler</h1><p className='mt-2'>Short article... Drip is better for water efficiency, sprinklers for large lawns...</p></main><Footer/></div>) }
