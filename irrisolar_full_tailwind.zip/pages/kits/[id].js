
import Head from 'next/head'
import Header from '../../components/Header'
import Footer from '../../components/Footer'
import kits from '../../data/kits'
import products from '../../data/products'
export async function getStaticPaths(){ const paths = kits.map(k=>({params:{id:k.id}})); return {paths, fallback:false} }
export async function getStaticProps({params}){ const kit = kits.find(k=>k.id===params.id); return {props:{kit}} }
export default function Kit({kit}){
  const kitProducts = kit.contents.map(id=> products.find(p=>p.id===id)).filter(Boolean)
  return (<div><Head><title>{kit.name} - Irrisolar</title></Head><Header/>
    <main className="pt-20 max-w-3xl mx-auto p-4">
      <div className="bg-white shadow rounded p-4">
        <img src={kit.image} className="w-full h-64 object-cover rounded"/>
        <h1 className="text-xl font-bold mt-3">{kit.name}</h1>
        <div className="text-green-700 font-bold">{kit.price}</div>
        <a href={`https://wa.me/254700000000?text=I%20want%20the%20${encodeURIComponent(kit.name)}`} className="block mt-3 bg-primary text-white text-center py-2 rounded">Order Kit via WhatsApp</a>
        <h3 className="font-bold mt-4">Includes</h3>
        <ul className="list-disc pl-5 mt-2">{kitProducts.map(p=>(<li key={p.id}>{p.name} — {p.price}</li>))}</ul>
      </div>
    </main><Footer/></div>)
}
